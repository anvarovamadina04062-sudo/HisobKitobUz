HisobKitobUz — Telegram Mini App boshlang‘ich versiya

Fayllar:
- index.html — ilovaning ishlaydigan sahifasi
- style.css — dizayn

Ishlatish:
1. index.html faylini Chrome’da oching.
2. Xarajat/Daromad tugmalarini sinab ko‘ring.
3. Ma’lumotlar hozircha shu brauzerning localStorage xotirasida saqlanadi.
4. Telegram Mini App qilish uchun keyingi bosqichda bu sahifani internetga joylab, BotFather orqali Web App tugmasiga ulaymiz.

Eslatma: haqiqiy ko‘p qurilmali saqlash uchun keyin server/database kerak bo‘ladi.
